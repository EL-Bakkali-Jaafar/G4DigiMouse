#include "DetectorConstruction.hh"
#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Orb.hh"
#include "G4Sphere.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <stdio.h> 
#include "Voxel.hh"
#include <iterator>
#include <sstream>
#include <vector>
#include <iostream>
#include <string>
#include "G4PVReplica.hh"
#include "G4tgbGeometryDumper.hh"
#include "G4VisAttributes.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Cons.hh"
#include "G4Orb.hh"
#include "G4Sphere.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4SDManager.hh"
#include "PhantomSD.hh"
#include "G4PVReplica.hh"
#include "G4VisAttributes.hh"
#include "DetectorMessenger.hh"
#include "G4TransportationManager.hh"
#include "G4tgbVolumeMgr.hh"
#include "G4UserLimits.hh"
#include "G4tgrMessenger.hh"
#include "G4LogicalVolumeStore.hh"
#include <iostream>       // std::cout
#include <string>         // std::string
#include <cstddef>         // std::size_t
using namespace std;
vx ***Voxels;

G4float lx_dim=0.0, ly_dim=0.0, lz_dim=0.0;
G4float hx_dim=100000, hy_dim=10000, hz_dim=10000;
 
// Numbers of voxels along x,y and z.
int Number_Of_Voxels_Along_x=190;
int Number_Of_Voxels_Along_y=496;
int Number_Of_Voxels_Along_z=52;
G4double PHANTOM_X_DIM=38*mm;
G4double PHANTOM_Y_DIM=99.2*mm;
G4double PHANTOM_Z_DIM=20.8*mm;
G4double VOXEL_X_DIM=PHANTOM_X_DIM/(double)Number_Of_Voxels_Along_x;//0.2 mm
G4double VOXEL_Y_DIM=PHANTOM_Y_DIM/(double)Number_Of_Voxels_Along_y;//0.2 mm
G4double VOXEL_Z_DIM=PHANTOM_Z_DIM/(double)Number_Of_Voxels_Along_z;//0.4 mm.
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::ContructMaterial()
{
G4double   density;
G4String name, symbol;
G4int ncomponents;
  G4Element* elementH = new G4Element( "Hydrogen",   "H",  1. , 1.00794*g/mole );
  G4Element* elementC = new G4Element( "Carbon",     "C",  6. , 12.01*g/mole );
  G4Element* elementN = new G4Element( "Nitrogen",   "N",  7. , 14.00674*g/mole );
  G4Element* elementO = new G4Element( "Oxygen",     "O",  8. , 15.9994*g/mole );
  G4Element* elementNa = new G4Element( "Sodium",    "Na", 11. , 22.98977*g/mole );
  G4Element* elementMg = new G4Element( "Magnesium", "Mg", 12. , 24.305*g/mole );
  G4Element* elementP = new G4Element( "Phosphorus", "P",  15. , 30.973762*g/mole );
  G4Element* elementS = new G4Element( "Sulphur",    "S",  16. , 32.06*g/mole );
  G4Element* elementCl = new G4Element( "Chlorine",  "Cl", 17. , 35.4527*g/mole );
  G4Element* elementK = new G4Element( "Potassium",  "K",  19. ,  39.098*g/mole );
  G4Element* elementCa = new G4Element( "Calcium",   "Ca", 20. , 40.078*g/mole );
  G4Element* elementFe = new G4Element( "Fer",       "Fe", 26. , 55.85*g/mole );
  G4Element* elementZn = new G4Element( "Zinc",      "Zn", 30. , 65.38*g/mole );
  G4Element* elementRb = new G4Element( "Rb",      "Rb", 37. , 85.47*g/mole );
  G4Element* elementSr = new G4Element( "Sr",      "Sr", 38. ,  87.62 *g/mole );
  G4Element* elementZr = new G4Element( "Zr",      "Zr", 40. , 91.22*g/mole );
  G4Element* elementPb = new G4Element( "Pb",      "Pb", 82. , 207.19*g/mole );


//__________________________________ICRP Publication 110_____________________________________________
// Air      
Air_material = new G4Material("Air_material",density=0.001*g/cm3,  ncomponents=2);
Air_material->AddElement( elementN,  80.0   *perCent);
Air_material->AddElement( elementO,   20.0  *perCent);
//Adipose_tissue     ID_0                                          
Adipose_tissue_material= new G4Material("Adipose_tissue_material",density=  0.950*g/cm3,  ncomponents=7);
Adipose_tissue_material->AddElement( elementH,  11.4 *perCent);
Adipose_tissue_material->AddElement( elementC,    58.9 *perCent);
Adipose_tissue_material->AddElement( elementN,    0.7  *perCent);
Adipose_tissue_material->AddElement( elementO,    28.7 *perCent);
Adipose_tissue_material->AddElement( elementNa,      0.1 *perCent);
Adipose_tissue_material->AddElement( elementS,     0.1    *perCent);
Adipose_tissue_material->AddElement( elementCl,       0.1  *perCent);
//Skin     ID_1         
Skin_material = new G4Material("Skin_material",density= 1.090*g/cm3,  ncomponents=9);
Skin_material->AddElement( elementH,  10.0*perCent);
Skin_material->AddElement( elementC,   19.9*perCent);
Skin_material->AddElement( elementN,   4.2*perCent);
Skin_material->AddElement( elementO,  65.0  *perCent);
Skin_material->AddElement( elementNa,    0.2*perCent);
Skin_material->AddElement( elementP,  0.1 *perCent);
Skin_material->AddElement( elementS,   0.2 *perCent);
Skin_material->AddElement( elementCl,   0.3*perCent);
Skin_material->AddElement( elementK,   0.1*perCent);
//Skeleton (MIRD)   ID_2       


  Skeleton_material = new G4Material("Skeleton_material",density=1.4862*g/cm3,15);
  Skeleton_material -> AddElement( elementH,0.0704);
  Skeleton_material -> AddElement( elementC,0.2279);
  Skeleton_material -> AddElement( elementN,0.0387);
  Skeleton_material -> AddElement( elementO,0.4856);
  Skeleton_material -> AddElement( elementNa,0.0032); 
  Skeleton_material -> AddElement( elementMg,0.0011); 
  Skeleton_material -> AddElement( elementP,0.0694);
  Skeleton_material -> AddElement( elementS,0.0017);
  Skeleton_material -> AddElement( elementCl,0.0014);
  Skeleton_material -> AddElement( elementK,0.0015);
  Skeleton_material -> AddElement( elementCa,0.0991);
  Skeleton_material -> AddElement( elementFe,0.00008);
  Skeleton_material -> AddElement( elementZn,0.000048);
  Skeleton_material -> AddElement( elementSr,0.000032);
  Skeleton_material -> AddElement( elementPb,0.000011);


//Eye      ID_3        
Eye_material = new G4Material("Eye_material",density=1.050*g/cm3,  ncomponents=8);
Eye_material ->AddElement( elementH,  9.7  *perCent);
Eye_material ->AddElement( elementC,  18.3 *perCent);
Eye_material ->AddElement( elementN,  5.4  *perCent);
Eye_material ->AddElement( elementO,  66.  *perCent);
Eye_material ->AddElement( elementNa, 0.1 *perCent);
Eye_material ->AddElement( elementP, 0.1 *perCent);
Eye_material ->AddElement( elementS, 0.3  *perCent);
Eye_material ->AddElement( elementCl, 0.1 *perCent);
//(cerebellum, external cerebrum, striatum, rest of the brain) ID_5  ID_7  ID_8  ID_10 
Whole_brain_material = new G4Material("Whole_brain_material",density= 1.050*g/cm3,  ncomponents=9);
Whole_brain_material->AddElement( elementH, 10.7  *perCent);
Whole_brain_material->AddElement( elementC,   14.3  *perCent);
Whole_brain_material->AddElement( elementN,  2.3 *perCent);
Whole_brain_material->AddElement( elementO,  71.3*perCent);
Whole_brain_material->AddElement( elementNa, 0.2 *perCent);
Whole_brain_material->AddElement( elementP,  0.4 *perCent);
Whole_brain_material->AddElement( elementS, 0.2  *perCent);
Whole_brain_material->AddElement( elementCl, 0.3 *perCent);
Whole_brain_material->AddElement( elementK,   0.3*perCent);


// MIRD soft tissue

  soft = new G4Material("soft_tissue",0.9869 *g/cm3,16);
  soft->AddElement( elementH,0.1047);
  soft->AddElement( elementC,0.2302);
  soft->AddElement( elementN,0.0234);
  soft->AddElement( elementO,0.6321);
  soft->AddElement( elementNa,0.0013);
  soft->AddElement( elementMg,0.00015);
  soft->AddElement( elementP,0.0024);
  soft->AddElement( elementS,0.0022);
  soft->AddElement( elementCl,0.0014);
  soft->AddElement( elementK,0.0021);
  soft->AddElement( elementFe,0.000063);
  soft->AddElement( elementZn,0.000032);
  soft->AddElement( elementRb,0.0000057);
  soft->AddElement( elementSr,0.00000034);
  soft->AddElement( elementZr,0.000008);
  soft->AddElement( elementPb,0.00000016);





//Heart  ID_9
Heart_material = new G4Material("Heart_material",density=1.050*g/cm3,  ncomponents=9);
Heart_material->AddElement( elementH, 10.4 *perCent);
Heart_material->AddElement( elementC,  13.8  *perCent);
Heart_material->AddElement( elementN,   2.9 *perCent);
Heart_material->AddElement( elementO, 71.9  *perCent);
Heart_material->AddElement( elementNa,  0.1 *perCent);
Heart_material->AddElement( elementP,  0.2  *perCent);
Heart_material->AddElement( elementS,  0.2  *perCent);
Heart_material->AddElement( elementCl,  0.2 *perCent);
Heart_material->AddElement( elementK, 0.3 *perCent);
// Masseter_muscles  	ID_11
Masseter_muscles_material = new G4Material("Masseter_muscles_material",density=1.050*g/cm3,  ncomponents=9);
Masseter_muscles_material->AddElement( elementH,  10.2 *perCent);
Masseter_muscles_material->AddElement( elementC,  14.2 *perCent);
Masseter_muscles_material->AddElement( elementN,    3.4*perCent);
Masseter_muscles_material->AddElement( elementO, 71.1 *perCent);
Masseter_muscles_material->AddElement( elementNa,  0.1 *perCent);
Masseter_muscles_material->AddElement( elementP,    0.2*perCent);
Masseter_muscles_material->AddElement( elementS,   0.3 *perCent);
Masseter_muscles_material->AddElement( elementCl, 0.1  *perCent);
Masseter_muscles_material->AddElement( elementK,    0.4 *perCent);
// Soft_tissue ( medulla, olfactory bulbs, lachrymal glands ) ID_4 ID_6 ID_12
Soft_tissue_material = new G4Material("Soft_tissue_material",density=1*g/cm3,  ncomponents=13);
Soft_tissue_material->AddElement(elementH, 	0.104472 );
Soft_tissue_material->AddElement(elementC,  	0.232190);
Soft_tissue_material->AddElement(elementN, 	0.024880 );
Soft_tissue_material->AddElement(elementO,	0.630238 );
Soft_tissue_material->AddElement(elementNa,  	0.001130 );
Soft_tissue_material->AddElement(elementMg,  	0.000130);
Soft_tissue_material->AddElement(elementP,	0.001330 );
Soft_tissue_material->AddElement(elementS,	0.001990);
Soft_tissue_material->AddElement(elementCl,	0.001340 );
Soft_tissue_material->AddElement(elementK,	0.001990);
Soft_tissue_material->AddElement(elementCa, 	0.000230 );
Soft_tissue_material->AddElement(elementFe,      0.000050);
Soft_tissue_material->AddElement(elementZn, 	0.000030);
//Bladder  ID_13
Bladder_material = new G4Material("Bladder_material",density=1.040*g/cm3,  ncomponents=9);
Bladder_material->AddElement( elementH, 10.5    *perCent);
Bladder_material->AddElement( elementC,    9.6  *perCent);
Bladder_material->AddElement( elementN,   2.6  *perCent);
Bladder_material->AddElement( elementO, 76.1  *perCent);
Bladder_material->AddElement( elementNa,   0.2   *perCent);
Bladder_material->AddElement( elementP,      0.2  *perCent);
Bladder_material->AddElement( elementS,     0.2  *perCent);
Bladder_material->AddElement( elementCl,  0.3  *perCent);
Bladder_material->AddElement( elementK, 0.3 *perCent);
//Testes     ID_14 
Testes_material= new G4Material("Testes_material",density=  1.040*g/cm3,  ncomponents=9);
Testes_material->AddElement( elementH,   10.6 *perCent);
Testes_material->AddElement( elementC,   10.0  *perCent);
Testes_material->AddElement( elementN,   2.1 *perCent);
Testes_material->AddElement( elementO,   76.4 *perCent);
Testes_material->AddElement( elementNa,   0.2 *perCent);
Testes_material->AddElement( elementP,    0.1  *perCent);
Testes_material->AddElement( elementS,   0.2  *perCent);
Testes_material->AddElement( elementCl,   0.2  *perCent);
Testes_material->AddElement( elementK,    0.2*perCent); 
// Stomach  ID_15         
Stomach_material = new G4Material("Stomach_material",density= 1.040*g/cm3,  ncomponents=9);
Stomach_material->AddElement( elementH,  10.5 *perCent);
Stomach_material->AddElement( elementC,  11.4 *perCent);
Stomach_material->AddElement( elementN,  2.5*perCent);
Stomach_material->AddElement( elementO,  75.0 *perCent);
Stomach_material->AddElement( elementNa, 0.1 *perCent);
Stomach_material->AddElement( elementP,  0.1 *perCent);
Stomach_material->AddElement( elementS,  0.1  *perCent);
Stomach_material->AddElement( elementCl, 0.2 *perCent);
Stomach_material->AddElement( elementK,  0.1 *perCent);
//Spleen  ID_16
Spleen_material = new G4Material("Spleen_material",density=1.040*g/cm3,  ncomponents=10);
Spleen_material->AddElement( elementH, 10.2 *perCent);
Spleen_material->AddElement( elementC,  11.1*perCent);
Spleen_material->AddElement( elementN,    3.3 *perCent);
Spleen_material->AddElement( elementO,  74.3  *perCent);
Spleen_material->AddElement( elementNa,   0.1 *perCent);
Spleen_material->AddElement( elementP,   0.2  *perCent);
Spleen_material->AddElement( elementS,    0.2*perCent);
Spleen_material->AddElement( elementCl,    0.3 *perCent);
Spleen_material->AddElement( elementK,    0.2 *perCent);
Spleen_material->AddElement( elementFe,   0.1 *perCent);   
//Pancreas     ID_17
Pancreas_material = new G4Material("Pancreas_material",density= 1.050*g/cm3,  ncomponents=9);
Pancreas_material->AddElement( elementH, 10.5  *perCent);
Pancreas_material->AddElement( elementC, 15.5  *perCent);
Pancreas_material->AddElement( elementN, 2.5 *perCent);
Pancreas_material->AddElement( elementO,   70.6*perCent);
Pancreas_material->AddElement( elementNa,  0.2 *perCent);
Pancreas_material->AddElement( elementP,  0.2  *perCent);
Pancreas_material->AddElement( elementS,  0.1  *perCent);
Pancreas_material->AddElement( elementCl,   0.2*perCent);
Pancreas_material->AddElement( elementK,  0.2*perCent);
//Liver        ID_18                                                                  
Liver_material = new G4Material("Liver_material",density=1.050*g/cm3,  ncomponents=9);
Liver_material->AddElement( elementH,   10.2 *perCent);
Liver_material->AddElement( elementC,  13.0 *perCent);
Liver_material->AddElement( elementN,   3.1 *perCent);
Liver_material->AddElement( elementO, 72.5  *perCent);
Liver_material->AddElement( elementNa, 0.2  *perCent);
Liver_material->AddElement( elementP,   0.2*perCent);
Liver_material->AddElement( elementS,   0.3  *perCent);
Liver_material->AddElement( elementCl,   0.2 *perCent);
Liver_material->AddElement( elementK,   0.3*perCent);
// Kidneys    ID_19
Kidney_material = new G4Material("Kidney_material",density=1.050*g/cm3,  ncomponents=10);
Kidney_material->AddElement( elementH, 10.3 *perCent);
Kidney_material->AddElement( elementC,  12.4 *perCent);
Kidney_material->AddElement( elementN,   3.1 *perCent);
Kidney_material->AddElement( elementO,   73.1 *perCent);
Kidney_material->AddElement( elementNa,  0.2 *perCent);
Kidney_material->AddElement( elementP,  0.2*perCent);
Kidney_material->AddElement( elementS,  0.2 *perCent);
Kidney_material->AddElement( elementCl,   0.2 *perCent);
Kidney_material->AddElement( elementK,  0.2  *perCent);
Kidney_material->AddElement( elementCa,   0.1 *perCent);
//Adrenals  ID_20
Adrenals_material = new G4Material("Adrenals_material",density=1.030*g/cm3,  ncomponents=9);
Adrenals_material->AddElement( elementH, 10.4  *perCent);
Adrenals_material->AddElement( elementC,     22.1 *perCent);
Adrenals_material->AddElement( elementN,    2.8 *perCent);
Adrenals_material->AddElement( elementO,    63.7*perCent);
Adrenals_material->AddElement( elementNa,   0.1  *perCent);
Adrenals_material->AddElement( elementP,      0.2  *perCent);
Adrenals_material->AddElement( elementS,     0.3  *perCent);
Adrenals_material->AddElement( elementCl,    0.2  *perCent);
Adrenals_material->AddElement( elementK,  0.2 *perCent);

//Lungs ICRP  ID_21

Lungs_material = new G4Material("Lungs_material",density=0.382*g/cm3,  ncomponents=9);
Lungs_material->AddElement( elementH, 10.3   *perCent);
Lungs_material->AddElement( elementC,  10.7   *perCent);
Lungs_material->AddElement( elementN,   3.2 *perCent);
Lungs_material->AddElement( elementO,  74.6  *perCent);
Lungs_material->AddElement( elementNa,     0.2 *perCent);
Lungs_material->AddElement( elementP,     0.2   *perCent);
Lungs_material->AddElement( elementS,    0.3   *perCent);
Lungs_material->AddElement( elementCl,    0.3 *perCent);
Lungs_material->AddElement( elementK,  0.2  *perCent);


 



}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string DetectorConstruction::OrganeName(const G4int OrganeId)
{
std::string _name="";
switch(OrganeId) 
{
case 0:
_name= "background";
break;
case 1:
 _name="skin";
break;
case 2:
_name="skeleton";
break;
case 3:
_name="eye";
break;
case 4:
_name="medulla";
break;
case 5:
_name="cerebellum";
break;
case 6:
_name="olfactory_bulbs";
break;
case 7:
_name="external_cerebrum";
break;
case 8:
_name="striatum";
break;
case 9:
_name= "heart";
break;
case 10:
_name="rest_of_the_brain";
break;
case 11:
_name= "masseter_muscles";
break;
case 12:
_name= "lachrymal_glands";
break;
case 13:
_name= "bladder";
break;
case 14:
_name= "testis";
break;
case 15:
_name= "stomach";
break;
case 16:
_name= "spleen";
break;
case 17:
_name="pancreas";
break;
case 18:
_name= "liver";
break;
case 19:
_name= "kidneys";
break;
case 20:
_name= "adrenal_glands";
break;
case 21:
 _name="lungs";
break;
default :

cout << "OrganeName_Invalid_id  " <<  OrganeId<< endl;
}
return _name;
}


/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4Material * DetectorConstruction::MaterialName(const G4int OrganId)
{
G4Material * material=0;
 switch(OrganId) 
{
case 0:
material= Adipose_tissue_material;
break;
case 1:
//
material= Skin_material;

break;
case 2:
material= Skeleton_material;

break;
case 3:

material= Eye_material;
break;
case 4:
material= Soft_tissue_material ;

break;
case 5:
material= Whole_brain_material;

break;
case 6:
material= Soft_tissue_material ;

break;
case 7:
material= Whole_brain_material;

break;
case 8:
material= Whole_brain_material;

break;
case 9:
material=Heart_material;

break;
case 10:
material= Whole_brain_material;
break;
case 11:

material= Masseter_muscles_material;

break;
case 12:
material= Soft_tissue_material ;
break;
case 13:

material= Bladder_material;
break;
case 14:
material= Testes_material;
break;
case 15:
material= Stomach_material;

break;
case 16:
material= Spleen_material;
break;
case 17:
material= Pancreas_material;
break;
case 18:
material= Liver_material;
break;
case 19:
material= Kidney_material;

break;
case 20:
material= Adrenals_material;
break;
case 21:
material= Lungs_material;
break;
default :
cout << "material_Invalid_id " <<  OrganId<< endl;
}
return material;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::set_kinetic_energy(G4double _kinetic_energy)
{ 
this->kinetic_energy=_kinetic_energy;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorConstruction::DetectorConstruction(): G4VUserDetectorConstruction()
{
pDetectorMessenger= new DetectorMessenger(this); 
//constructing voxels and initializing them.

Voxels=new vx**[Number_Of_Voxels_Along_x];
for (int ix=0; ix<Number_Of_Voxels_Along_x; ix++)
{
Voxels[ix]=new vx*[ Number_Of_Voxels_Along_y];
for (int iy=0; iy<  Number_Of_Voxels_Along_y; iy++)
{
Voxels[ix][iy]=new vx[ Number_Of_Voxels_Along_z];
for (int iz=0; iz<  Number_Of_Voxels_Along_z; iz++)
{
Voxels[ix][iy][iz].organe="0";
}}}

// process file
ifstream inFile;
inFile.open("../G4DigiMouse_code/mouse.dat");
std::string str;
vector<string> data;

static int total_number_of_voxels=0;
while (std::getline(inFile,str))
{
total_number_of_voxels++;
std::vector<std::string> result;
std::istringstream iss(str);
for(std::string s_data; iss >> s_data; )
{
   result.push_back(s_data);
}
int ix=0;
int iy=0;
int iz=0;
std::string  organ_id="";
ix=std::stoi( result[0]);
iy=std::stoi( result[1]);
iz=std::stoi( result[2]);
organ_id= result[3];
Voxels[ix][iy][iz].organe=organ_id;
}


cout<< "InterDosi_code-> total number of voxels : "<< total_number_of_voxels << '\n' <<endl;  

inFile.close();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetNumberOfThreads( int _NumberOfThread)
{
this->NumberOfThread=_NumberOfThread;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetNumberOfSameParticle( int _NumberOfSameParticle)
{
this->NumberOfSameParticle=_NumberOfSameParticle;
cout<< "InterDosi_code-> NumberOfSameParticle; : "<<NumberOfSameParticle << '\n' <<endl;  
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorConstruction::~DetectorConstruction()
{ 
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4VPhysicalVolume* DetectorConstruction::Construct()
{  
this->runManager = G4RunManager::GetRunManager();
this->Total_Events_To_Be_Processed= this->runManager->GetNumberOfEventsToBeProcessed();
this->NumberOfThread=G4Threading::G4GetNumberOfCores();
ContructMaterial();
// Get nist material manager
G4NistManager* nist = G4NistManager::Instance();
G4bool checkOverlaps = true;
G4Material* world_mat = nist->FindOrBuildMaterial("G4_AIR");
G4Box* solidWorld =new G4Box("World",  0.55*PHANTOM_X_DIM, 0.55*PHANTOM_Y_DIM, 0.55*PHANTOM_Z_DIM);  
G4LogicalVolume* logicWorld =  new G4LogicalVolume(solidWorld,world_mat,"World");           
logicWorld ->SetVisAttributes(G4VisAttributes::GetInvisible());   
this->physWorld =  new G4PVPlacement(0,G4ThreeVector(),logicWorld,"World",0, false, 0,checkOverlaps);        

if (this->ConstructSourceVolumePoints_Flag==true) {
Construct_ICRP_adult_male_ConstructSourceVolumePoints(new G4ThreeVector(0.0,0.0,0.0)) ;

} else {
//
Construct_ICRP_adult_male( new G4ThreeVector(0.0,0.0,0.0));
//G4tgbGeometryDumper::GetInstance()->DumpGeometry("digi_mouse.geom");
//G4tgbVolumeMgr* volmgr = G4tgbVolumeMgr::GetInstance();
//volmgr->AddTextFile("digi_mouse.geom");
//this->physWorld = volmgr->ReadAndConstructDetector();

}


//







return this->physWorld;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ConstructSDandField(){

int SensitiveDetectors[21]= {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21};
G4SDManager* pSDManager = G4SDManager::GetSDMpointer();
G4ThreadLocal PhantomSD *mSD = new PhantomSD("Phantom");
pSDManager-> AddNewDetector(mSD);

//
if (this->ConstructSourceVolumePoints_Flag==false) 
{
cout<< "list Of SensitiveDetectors " <<G4endl;

for ( int i=0;i< 21 ;i++) 
{ 
cout<< " "<<OrganeName(SensitiveDetectors[i])<<G4endl;
SetSensitiveDetector(OrganeName(SensitiveDetectors[i]),mSD);
//
}
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::setConstructSourceVolumePoints_Flag(bool _ConstructSourceVolumePoints_Flag) {
this->ConstructSourceVolumePoints_Flag = _ConstructSourceVolumePoints_Flag;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

void DetectorConstruction::set_particle_name(std::string  _particle_name) {
this->particle_name = _particle_name;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4double DetectorConstruction::GetOrganeDensity(int  _organ_id) {
G4double density=0.0*g/cm3;

density= MaterialName(_organ_id)->GetDensity();
return density/(g/cm3) ;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4double DetectorConstruction::GetOrganTotalVoxelizedVolume(const std::string _OrganTotalVoxelizedVolumeName)
{
 int l=0;
G4double _OrganTotalVoxelizedVolume=0.0;
 for (int ix=0; ix< Number_Of_Voxels_Along_x; ix++){
 for (int iy=0; iy< Number_Of_Voxels_Along_y; iy++){
 for (int iz=0; iz< Number_Of_Voxels_Along_z; iz++){
//
if (Voxels[ix][iy][iz].organe!="0"   ) {
if (OrganeName(std::stoi(Voxels[ix][iy][iz].organe))==_OrganTotalVoxelizedVolumeName )

{

l++;
}}}};
}
  _OrganTotalVoxelizedVolume=l* VOXEL_X_DIM*VOXEL_Y_DIM*VOXEL_Z_DIM;

return   _OrganTotalVoxelizedVolume/(cm*cm*cm);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::ConstructLogicalVolumes(G4String _SourceOrganeName){
G4Box*  Voxel = new G4Box("Voxel", VOXEL_X_DIM/2.0, VOXEL_Y_DIM/2.0, VOXEL_Z_DIM/2.0);
//
for (int OrganeId=1; OrganeId< 22; OrganeId++)
{

tmp[OrganeId]= new G4LogicalVolume(Voxel, MaterialName(OrganeId),OrganeName(OrganeId), 0, 0, 0);
//
G4double u= (double)rand() / (double)RAND_MAX;
//
G4double v= (double)rand() / (double)RAND_MAX;
//
G4double w= (double)rand() / (double)RAND_MAX;
G4VisAttributes * _attribut=  new G4VisAttributes( G4Colour(u,v, w)); 
if (this->ConstructSourceVolumePoints_Flag==false) {

tmp[OrganeId]->SetVisAttributes(_attribut);

}
if (this->ConstructSourceVolumePoints_Flag==true) {
tmp[OrganeId]->SetVisAttributes(G4VisAttributes::GetInvisible());

if ( OrganeName(OrganeId)==_SourceOrganeName) {


_attribut->SetForceSolid(true); // force the object to be visualized with a surface
_attribut->SetForceAuxEdgeVisible(true); // force auxiliary edges to be shown

tmp[OrganeId]->SetVisAttributes(_attribut);};
}
}
 
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

void  DetectorConstruction::SetMaxNumberOfPointsInOrgan( int _MaxNumberOfPointsInOrgan){

this->MaxNumberOfPointsInOrgan=_MaxNumberOfPointsInOrgan;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

void  DetectorConstruction::SetSourceOrganeName( G4String _SourceOrganeName){

this->SourceOrganeName=_SourceOrganeName;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4ThreeVector DetectorConstruction::GetHigherDimCubicVolumeEncapsulatingOrgan(G4float x, G4float y, G4float z ) 
{
G4ThreeVector v;

if (x > lx_dim) lx_dim=x;
if (y > ly_dim) ly_dim=y;
if (z > lz_dim) lz_dim=z;
v.setX(lx_dim);
v.setY(ly_dim);
v.setZ(lz_dim);


return v;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4ThreeVector DetectorConstruction::GetLowerDimCubicVolumeEncapsulatingOrgan(G4float x, G4float y, G4float z ) 
{
G4ThreeVector v;
if (x < hx_dim  ) hx_dim=x;
if (y < hy_dim )  hy_dim=y;
if (z < hz_dim  ) hz_dim=z;
v.setX(hx_dim);
v.setY(hy_dim);
v.setZ(hz_dim);
return v;
}


void DetectorConstruction::Construct_ICRP_adult_male_ConstructSourceVolumePoints( G4ThreeVector* center_position) 
{
ConstructLogicalVolumes(this->SourceOrganeName);
G4ThreeVector FIRST_VECTOR_POS,LAST_VECTOR_POS ;
int j=0;
for (int ix=0; ix< Number_Of_Voxels_Along_x; ix++){
for (int iy=0; iy< Number_Of_Voxels_Along_y; iy++){
for (int iz=0; iz< Number_Of_Voxels_Along_z; iz++){
if (OrganeName(std::stoi(Voxels[ix][iy][iz].organe))==this->SourceOrganeName)  
{
j++;
FIRST_VECTOR_POS=GetHigherDimCubicVolumeEncapsulatingOrgan(center_position->x()+((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM,center_position->y()+((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM, center_position->z()+((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM );

LAST_VECTOR_POS= GetLowerDimCubicVolumeEncapsulatingOrgan(center_position->x()+((ix)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM,center_position->y()+((iy)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM, center_position->z()+((iz)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM );

new G4PVPlacement(0,G4ThreeVector(center_position->x()+((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM,center_position->y()+((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM, center_position->z()+((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM),OrganeName(std::stoi(Voxels[ix][iy][iz].organe))+"_"+std::to_string(ix)+"_"+std::to_string(iy)+"_"+std::to_string(iz), tmp[std::stoi(Voxels[ix][iy][iz].organe)]
,this->physWorld,false,0);
}
}
}
}
DimCubicVolumeEncapsulatingOrgan.setX(2*( (FIRST_VECTOR_POS.x()  - LAST_VECTOR_POS.x() )/2.0  + 0.25*VOXEL_X_DIM ));
DimCubicVolumeEncapsulatingOrgan.setY(2*( (FIRST_VECTOR_POS.y()  - LAST_VECTOR_POS.y() )/2.0  + 0.25*VOXEL_Y_DIM ));
DimCubicVolumeEncapsulatingOrgan.setZ(2*( (FIRST_VECTOR_POS.z()  - LAST_VECTOR_POS.z() )/2.0  + 0.25*VOXEL_Z_DIM  ));
DimCubicVolumeEncapsulatingOrganPos.setX(FIRST_VECTOR_POS.x()- ((   FIRST_VECTOR_POS.x()  -   LAST_VECTOR_POS.x() )/2.0  - 0.25*VOXEL_X_DIM  ));
DimCubicVolumeEncapsulatingOrganPos.setY(FIRST_VECTOR_POS.y()- (( FIRST_VECTOR_POS.y()  - LAST_VECTOR_POS.y() )/2.0  - 0.25*VOXEL_Y_DIM  ));
DimCubicVolumeEncapsulatingOrganPos.setZ(FIRST_VECTOR_POS.z()- ((  FIRST_VECTOR_POS.z()  -  LAST_VECTOR_POS.z() )/2.0  - 0.25*VOXEL_Z_DIM  ));
/*

G4Box*  GHOST_VOL = new G4Box("GHOST_VOL",( (FIRST_VECTOR_POS.x()  - LAST_VECTOR_POS.x() )/2.0  + 0.25*VOXEL_X_DIM ),( (FIRST_VECTOR_POS.y()  - LAST_VECTOR_POS.y() )/2.0  + 0.25*VOXEL_Y_DIM ), ( (FIRST_VECTOR_POS.z()  - LAST_VECTOR_POS.z() )/2.0  + 0.25*VOXEL_Z_DIM  ));
G4LogicalVolume *GHOST_LOGICAL_VOL= new G4LogicalVolume(GHOST_VOL,MaterialName(1),"GHOST_LOGICAL_VOL", 0, 0, 0);
new G4PVPlacement(0,G4ThreeVector(DimCubicVolumeEncapsulatingOrganPos.x(),DimCubicVolumeEncapsulatingOrganPos.y(),DimCubicVolumeEncapsulatingOrganPos.z()),"GHOST_PHYSICAL_VOL",GHOST_LOGICAL_VOL,this->physWorld,false,0);
*/
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::Construct_ICRP_adult_male( G4ThreeVector* center_position) 
{
//int iz=44;
ConstructLogicalVolumes(this->SourceOrganeName);
for (int ix=0; ix< Number_Of_Voxels_Along_x; ix++){
for (int iy=0; iy< Number_Of_Voxels_Along_y; iy++){
//
for (int iz=0; iz< Number_Of_Voxels_Along_z; iz++)
{
if (Voxels[ix][iy][iz].organe!="0" ){

 ptmp[ix*iy*iz] =new G4PVPlacement(0,G4ThreeVector(center_position->x()+((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM,center_position->y()+((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM, center_position->z()+((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM),this->SourceOrganeName+"_"+std::to_string(ix)+"_"+std::to_string(iy)+"_"+std::to_string(iz), tmp[std::stoi(Voxels[ix][iy][iz].organe)]
,this->physWorld,false,ix*iy*iz);



}}}}}
