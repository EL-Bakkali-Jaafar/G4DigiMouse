/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
G4Linac_MT, a simple-to-use open source code developed to facilitate the use of Geant4 C++ toolkit for
the simulation of medical linear accelerator.
Author: Pr. Jaafar EL Bakkali, Assistant Professor of Nuclear Physics, Rabat, Morocco.
E-mail: bahmedj@gmail.com
For documentation see http://G4Linac_MT.github.com
09/11/2018: public version 1.6
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
#include "G4Run.hh"
#include "G4Event.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4VSolid.hh"
#include "G4LogicalVolume.hh"
#include "G4VPhysicalVolume.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4RunManager.hh"
#include "G4SDManager.hh"
#include "G4ParticleDefinition.hh"
#include "G4VVisManager.hh"
#include "G4Colour.hh"
#include "G4VisAttributes.hh"
#include "G4UnitsTable.hh"
#include "G4Circle.hh"
#include "G4ThreeVector.hh"
#include "G4ios.hh"
#include <stdio.h>
#include "PhantomSD.hh"
#include "DetectorConstruction.hh"
#include <vector>
#include "G4SystemOfUnits.hh"
#include "G4Threading.hh"
#include "G4Threading.hh"
#include "G4EventManager.hh"
#include "G4Threading.hh"
#include "G4AutoLock.hh"
#include <iostream>
#include <math.h>
#include <fstream>
using namespace std;
G4ThreadLocal     int                         fuse=-1;
G4ThreadLocal     int                         last_event_id=0;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PhantomSD::PhantomSD(G4String name )
: G4VSensitiveDetector(name)
{ 
this->runManager = G4RunManager::GetRunManager();

this->pDetectorConstruction = (DetectorConstruction*)(this->runManager->GetUserDetectorConstruction()); 
if (this->pDetectorConstruction->ConstructSourceVolumePoints_Flag==false){

this-> NumberOfThreads =pDetectorConstruction->NumberOfThread;
this-> NumberTotalEvents=0;
this-> VoxelVolume=0.;
this-> VoxelMass=0.*g;
this->pDetectorConstruction->NumberOfThread=G4Threading::GetNumberOfRunningWorkerThreads();
int SensitiveDetectors[21]= {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21};
this->_InterDosiData = new InterDosiData[21];
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
for ( unsigned short int i=0;i< 21 ;i++) 
{ 
this->_InterDosiData[i].ORGANE_ID=SensitiveDetectors[i];
this->_InterDosiData[i].ORGANE_NAME=this->pDetectorConstruction->OrganeName(SensitiveDetectors[i]);
this->_InterDosiData[i].KINETIC_ENERGY=0.0;
this->_InterDosiData[i].ABSORBED_ENERGY=0.0;
this->_InterDosiData[i].ABSORBED_ENERGY2=0.0;
this->_InterDosiData[i].STD_DEV=0.0;
this->_InterDosiData[i].NEVENT=0;
this->_InterDosiData[i].PHOT_COUNT=0;
this->_InterDosiData[i].CMPT_COUNT=0;
this->_InterDosiData[i].PAIREE_COUNT=0;
this->_InterDosiData[i].ORGANE_MASSE=0;
this->_InterDosiData[i].ORGANE_VOLUME=0;
}
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PhantomSD::~PhantomSD()
{

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4bool PhantomSD::ProcessHits(G4Step* aStep,G4TouchableHistory*)
{//1
if (this->pDetectorConstruction->ConstructSourceVolumePoints_Flag==false)
{//2
G4double ENERGY_DEPOSIT = aStep -> GetTotalEnergyDeposit();
ENERGY_DEPOSIT *=MeV;
if(ENERGY_DEPOSIT  == 0.) return false;
if(ENERGY_DEPOSIT  != 0) 
{ //3
const G4VProcess* aProcess =aStep -> GetPostStepPoint() ->GetProcessDefinedStep();

//G4cout<<"aProcess " <<aProcess->GetProcessName() <<G4endl;
for (int i= 0;i<21; i++)
{//4
if (this->_InterDosiData[i].ORGANE_NAME==aStep -> GetPostStepPoint() -> GetPhysicalVolume() -> GetLogicalVolume()->GetName())
{//5

this->_InterDosiData[i].ABSORBED_ENERGY+=ENERGY_DEPOSIT/(MeV);
this->_InterDosiData[i].ABSORBED_ENERGY2+= (ENERGY_DEPOSIT*ENERGY_DEPOSIT)/(MeV*MeV);

this->_InterDosiData[i].NEVENT++;
if (aProcess->GetProcessName()=="phot") {this->_InterDosiData[i].PHOT_COUNT++;}
else
if (aProcess->GetProcessName()=="compt") {this->_InterDosiData[i].CMPT_COUNT++;} 
else
if (aProcess->GetProcessName()=="conv")  
{this->_InterDosiData[i].PAIREE_COUNT++;}


if(this->_InterDosiData[i].NEVENT>1)
{//6
G4double absorbed_energy =this->_InterDosiData[i].ABSORBED_ENERGY;
G4double absorbed_energy2=this->_InterDosiData[i].ABSORBED_ENERGY2;
G4double absorbed_energy_mean=absorbed_energy/this->_InterDosiData[i].NEVENT;
G4double absorbed_energy2_mean=absorbed_energy2/this->_InterDosiData[i].NEVENT;
G4double sigma=sqrt((absorbed_energy2_mean-absorbed_energy_mean*absorbed_energy_mean)/(this->_InterDosiData[i].NEVENT-1));
this->_InterDosiData[i].STD_DEV= 100*sigma/absorbed_energy_mean;
}//6
}//5
}//4
}//3
}//2
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::EndOfEvent(G4HCofThisEvent*)
{

if (this->pDetectorConstruction->ConstructSourceVolumePoints_Flag==false)
{
 const G4Event * event                           = this->runManager ->GetCurrentEvent();
this->Total_Events_To_Be_Processed               = this->runManager ->GetNumberOfEventsToBeProcessed();
G4int event_id                                   = event->GetEventID();
G4ThreadLocal int b                              = (int) this->Total_Events_To_Be_Processed/(float) pDetectorConstruction->NumberOfThread;
if (  fuse==-1)
{
last_event_id=event_id+ b-1;
G4cout<< "FIRST_EVENT_ID  "<< event_id << " lAST_EVENT_ID "<<event_id+ b-1<<" THREAD_ID  "<<G4Threading::G4GetThreadId()<<  G4endl;
 fuse=1;
}

if( event_id==last_event_id )
{

//SaveDataInTextFile();
G4cout<< " EVENT_ID  "<< event_id << " THREAD_ID "<<G4Threading::G4GetThreadId()<<  G4endl;

SaveDataInBinaryFile();

}
}


}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::SaveDataInTextFile()

{//1
G4ThreadLocal std::ofstream  TextFile;
int NumberOfSameParticle=this->pDetectorConstruction->NumberOfSameParticle;
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
TextFile.open(this->pDetectorConstruction->SourceOrganeName+"_E"+ std::to_string(this->pDetectorConstruction->kinetic_energy)+"_"+str_thread +".sim", std::ios::out);
 this->Total_Events=(NumberOfSameParticle*this->Total_Events_To_Be_Processed) /this->pDetectorConstruction->NumberOfThread;

TextFile 
        << std::scientific
        <<"===========================================================================================\nSOURCE_EMITTED_ENERGY: " 
        <<this->pDetectorConstruction->kinetic_energy    
        <<" MeV.  \nNUMBER OF SIMULATED EVENTS PER THREAD: "
        <<Total_Events<<G4endl;
    G4cout    <<"\nNUMBER OF SIMULATED EVENTS PER THREAD: "
        <<Total_Events<<G4endl;

for (int i= 0;i<21; i++) 
{//2
//G4cout<< " vol "<<  this->_InterDosiData[i].ORGANE_NAME <<" NEvent "<<this->_InterDosiData[i].NEVENT<< G4endl;
ORGANE_MASSE=this->pDetectorConstruction->GetOrganeDensity(this->_InterDosiData[i].ORGANE_ID)*this->pDetectorConstruction->GetOrganTotalVoxelizedVolume(this->_InterDosiData[i].ORGANE_NAME)/1000;
BODY_MASSE+=ORGANE_MASSE;
SAF=((this->_InterDosiData[i].ABSORBED_ENERGY/Total_Events)/ORGANE_MASSE )/this->pDetectorConstruction->kinetic_energy  ;
PHOT_COUNT= 100*this->_InterDosiData[i].PHOT_COUNT/(float)(this->_InterDosiData[i].CMPT_COUNT  +this->_InterDosiData[i].PHOT_COUNT);
CMPT_COUNT= 100*this->_InterDosiData[i].CMPT_COUNT/(float)(this->_InterDosiData[i].CMPT_COUNT  +this->_InterDosiData[i].PHOT_COUNT);
ABSORBED_ENERGY=this->_InterDosiData[i].ABSORBED_ENERGY;
OrganTotalVoxelizedVolume=this->pDetectorConstruction->GetOrganTotalVoxelizedVolume(this->_InterDosiData[i].ORGANE_NAME);
NEVENT=this->_InterDosiData[i].NEVENT;
TextFile <<"===============================================================" 
         <<"\nORGANE_NAME: " 
         <<std::fixed
         <<this->_InterDosiData[i].ORGANE_NAME     
         <<"\nORGANE_MASSE (Kg): " 
         <<ORGANE_MASSE    
         <<"\nORGANE_VOLUME (CM_3 ): "
         <<OrganTotalVoxelizedVolume
         <<"\nABSORBED_ENERGY (MeV): " 
         <<ABSORBED_ENERGY 
         <<"\nSPECIFIC_ABSORBED_FRACTION (Kg-1): " 
         << std::scientific
         <<SAF 
         <<"\nNEVENT: " 
         << NEVENT
         <<std::fixed<<"\nSTD_DEV (%): " << this->_InterDosiData[i].STD_DEV 
         <<"\nPHOT_COUNT (%): "<< std::fixed<<PHOT_COUNT
         <<"\nCMPT_COUNT (%): " << CMPT_COUNT
         << G4endl;
}//2
BODY_MASSE=BODY_MASSE*1000;//Kg to g conversion.
TextFile <<"===============================================================" 
         << "\nBODY_MASSE (g): "  << BODY_MASSE<<"\n" <<G4endl;

float BODY_MASSE_REFERENCE=0;
float reference_masses[21]=
{
17
,1.7
,5.8e-3
,4.8e-2
,2.7e-2
,1.9e-2
,1.4e-1
,3.2e-2
,2.3e-1
,1.6e-1
,1.1e-1
,3.2e-2
,2.0e-1
,1.6e-1
,2.3e-1
,1.4e-1
,4.7e-2
, 2.1
,5.1e-1
,5.9e-3
,1.2e-1
};

for (int i= 0;i<21; i++) {//3
 BODY_MASSE_REFERENCE+=reference_masses[i];
}//3

TextFile <<"\nBODY_MASSE REFERENCE (g): "  
         <<BODY_MASSE_REFERENCE
         <<"\nBODY_MASSE DIFF (%): "  
         <<100* (1 -(BODY_MASSE_REFERENCE/BODY_MASSE))
         <<G4endl;
TextFile <<"Organ"<<"\t\t" << " MASSE_DIFF " << G4endl;
for (int i= 0;i<21; i++) 
{//4
ORGANE_MASSE=this->pDetectorConstruction->GetOrganeDensity(this->_InterDosiData[i].ORGANE_ID)*this->pDetectorConstruction->GetOrganTotalVoxelizedVolume(this->_InterDosiData[i].ORGANE_NAME);
TextFile 
         <<std::fixed
         <<this->_InterDosiData[i].ORGANE_NAME
         //<<"\nG4: "
         //<< ORGANE_MASSE
         //<<"\nREF:" 
         //<<reference_masses[i] 
         <<"\t"<< 100*(1- (reference_masses[i]/ORGANE_MASSE))
         << G4endl;
}//4
TextFile.close();
}//1
void PhantomSD::clear(){} 
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::DrawAll(){}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::PrintAll(){

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::SaveDataInBinaryFile()

{//1
G4ThreadLocal fstream fs;
InterDosiData tmp_InterDosiData;
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
fs.open(this->pDetectorConstruction->SourceOrganeName+"_E"+ std::to_string(this->pDetectorConstruction->kinetic_energy)+"_"+str_thread +".dat", ios::out | ios::binary );
 for (int i=0;i<21;i++) {
tmp_InterDosiData.ORGANE_ID        = this->_InterDosiData[i].ORGANE_ID;
tmp_InterDosiData.ORGANE_NAME      = this->_InterDosiData[i].ORGANE_NAME;
tmp_InterDosiData.KINETIC_ENERGY   = this->pDetectorConstruction->kinetic_energy/MeV;
tmp_InterDosiData.ABSORBED_ENERGY  = this->_InterDosiData[i].ABSORBED_ENERGY;
tmp_InterDosiData.ABSORBED_ENERGY2 = this->_InterDosiData[i].ABSORBED_ENERGY2;
tmp_InterDosiData.STD_DEV          = this->_InterDosiData[i].STD_DEV;
tmp_InterDosiData.NEVENT           = this->_InterDosiData[i].NEVENT;
tmp_InterDosiData.PHOT_COUNT       = this->_InterDosiData[i].PHOT_COUNT;
tmp_InterDosiData.CMPT_COUNT       = this->_InterDosiData[i].CMPT_COUNT;
tmp_InterDosiData.PAIREE_COUNT     = this->_InterDosiData[i].PAIREE_COUNT;
tmp_InterDosiData.ORGANE_VOLUME    = this->pDetectorConstruction->GetOrganTotalVoxelizedVolume(_InterDosiData[i].ORGANE_NAME);
tmp_InterDosiData.ORGANE_MASSE     = this->pDetectorConstruction->GetOrganeDensity(_InterDosiData[i].ORGANE_ID)*this->pDetectorConstruction->GetOrganTotalVoxelizedVolume(_InterDosiData[i].ORGANE_NAME)/1000;//Kg


fs.write(reinterpret_cast<char *>(&tmp_InterDosiData),sizeof(InterDosiData));

}
fs.close();
G4cout<<"InterDosiData-> SAVING DOSIMETRIC DATA FROM THREAD:  "<< G4Threading::G4GetThreadId()<<G4endl;
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
