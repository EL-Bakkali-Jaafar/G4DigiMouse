//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// $Id: PrimaryGeneratorAction.cc 94307 2015-11-11 13:42:46Z gcosmo $
//
/// \file PrimaryGeneratorAction.cc
/// \brief Implementation of the PrimaryGeneratorAction class
#include "DetectorConstruction.hh"
#include "PrimaryGeneratorAction.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4Box.hh"
#include "G4RunManager.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "G4Navigator.hh"
#include "G4TransportationManager.hh"
#include "G4ThreeVector.hh"
#include <iostream>
#include <math.h>
#include <fstream>
#include "G4EventManager.hh"
using namespace std;
G4ThreadLocal int INCR_NUMBER_OF_POINTS_IN_CURRENT_ORGANE =0;
G4ThreadLocal unsigned int max_points=0;
const unsigned long infinity=1000000000000000;
const unsigned int NUMBER_OF_POINTS_PER_CM3_UNIT=15000000;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

PrimaryGeneratorAction::PrimaryGeneratorAction()
: G4VUserPrimaryGeneratorAction(),fParticleGun(0)
{
pos_read                               = 0;
fParticleGun                           = new G4ParticleGun(1);
INCR_NUMBER_OF_POINTS_IN_CURRENT_ORGANE= 0;
j                                      =-1;
auto str_thread                        = std::to_string(G4Threading::G4GetThreadId());
this->runManager                       = G4RunManager::GetRunManager();
this->pDetectorConstruction            = (DetectorConstruction*)(runManager->GetUserDetectorConstruction()); 
max_points                             = this->pDetectorConstruction ->MaxNumberOfPointsInOrgan;
_ConstructSourceVolumePoints_flag      = this->pDetectorConstruction->ConstructSourceVolumePoints_Flag;
G4ParticleTable* particleTable         = G4ParticleTable::GetParticleTable();
G4ParticleDefinition* particle         = particleTable->FindParticle(this->pDetectorConstruction->particle_name);
fParticleGun                           ->SetParticleDefinition(particle);
fParticleGun                           ->SetParticleEnergy(this->pDetectorConstruction->kinetic_energy);

G4cout<<"G4DigiMouse->  Primary kinetic Energy (MeV) : "  << this->pDetectorConstruction->kinetic_energy<<G4endl;

if (this->pDetectorConstruction->ConstructSourceVolumePoints_Flag==false) 
{
binary_file.open(this->pDetectorConstruction->SourceOrganeName+".dat",std::ios::binary|std::ios::in| std::ios::ate );
size=binary_file.tellg();
cout<< "G4DigiMouse-> Read Binary File : "<<this->pDetectorConstruction->SourceOrganeName<<".dat"<<" contains "<< size/ (int) sizeof(OrgansPositionData) << " points."<<endl;
}


}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
  delete fParticleGun;
}
void PrimaryGeneratorAction::ReadBinaryFile()
{

int b= size/ (int) sizeof(OrgansPositionData);
if ( pos_read== b) pos_read=0;
OrgansPositionData _OrgansPositionData ;
binary_file.seekg(sizeof(OrgansPositionData)*pos_read);
binary_file.read((char*)&_OrgansPositionData,sizeof(OrgansPositionData));
G4double u= (double)rand() / (double)RAND_MAX;
G4double v= (double)rand() / (double)RAND_MAX;
G4double w= (double)rand() / (double)RAND_MAX;
fParticleGun->SetParticlePosition(G4ThreeVector(_OrgansPositionData.x,_OrgansPositionData.y,_OrgansPositionData.z));
fParticleGun->SetParticleMomentumDirection(G4ThreeVector(u,v,w));
pos_read++;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::BuildOrgansPositionDataFiles()

{
OrgansPositionData _OrgansPositionData;
fstream fs;
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
fs.open(this->pDetectorConstruction->SourceOrganeName +".dat",  ios_base::app | ios_base::out );
G4Navigator* aNavigator = G4TransportationManager::GetTransportationManager()->GetNavigatorForTracking();
G4double PHANTOM_X_DIM=this->pDetectorConstruction->DimCubicVolumeEncapsulatingOrgan.x();
G4double PHANTOM_Y_DIM=this->pDetectorConstruction->DimCubicVolumeEncapsulatingOrgan.y();
G4double PHANTOM_Z_DIM=this->pDetectorConstruction->DimCubicVolumeEncapsulatingOrgan.z();
int NUMBER_OF_POINTS_IN_CURRENT_ORGANE= this->pDetectorConstruction->MaxNumberOfPointsInOrgan;
G4cout <<"G4DigiMouse->Cubic Volume Encapsulating Organ  " <<this->pDetectorConstruction->SourceOrganeName << G4endl;
G4cout <<"G4DigiMouse->Cubic Volume Encapsulating Organ Center Pos X " <<this->pDetectorConstruction->DimCubicVolumeEncapsulatingOrganPos.x() << G4endl;
G4cout <<"G4DigiMouse->Cubic Volume Encapsulating Organ Center Pos Y "<<this->pDetectorConstruction->DimCubicVolumeEncapsulatingOrganPos.y()<< G4endl;
G4cout <<"G4DigiMouse->Cubic VolumeEncapsulating  Organ Center Pos Z " <<this->pDetectorConstruction->DimCubicVolumeEncapsulatingOrganPos.z()<< G4endl;
G4cout <<"G4DigiMouse->Cubic Volume Encapsulating Organ dimension x " <<PHANTOM_X_DIM << G4endl;
G4cout <<"G4DigiMouse->Cubic Volume Encapsulating Organ dimension y  " <<PHANTOM_Y_DIM << G4endl;
G4cout <<"G4DigiMouse->Cubic Volume Encapsulating Organ dimension z " <<PHANTOM_Z_DIM << G4endl;
for (unsigned int r=0; r< infinity; r++)
 {
G4double x=(this->pDetectorConstruction->DimCubicVolumeEncapsulatingOrganPos.x()+ 0.5*PHANTOM_X_DIM) - PHANTOM_X_DIM*(double)rand() / (double)RAND_MAX;
G4double y= (this->pDetectorConstruction->DimCubicVolumeEncapsulatingOrganPos.y()+0.5*PHANTOM_Y_DIM) - PHANTOM_Y_DIM*(double)rand() / (double)RAND_MAX;
G4double z=( this->pDetectorConstruction->DimCubicVolumeEncapsulatingOrganPos.z()+0.5*PHANTOM_Z_DIM) - PHANTOM_Z_DIM*(double)rand() / (double)RAND_MAX;
G4VPhysicalVolume* aVolume = aNavigator->LocateGlobalPointAndSetup(G4ThreeVector( x,y,z));
if ( aVolume->GetLogicalVolume()->GetName() == this->pDetectorConstruction->SourceOrganeName)
{
_OrgansPositionData.x=x;
_OrgansPositionData.y=y;
_OrgansPositionData.z=z;
fs.write(reinterpret_cast<char *>(&_OrgansPositionData),sizeof(OrgansPositionData));
INCR_NUMBER_OF_POINTS_IN_CURRENT_ORGANE++;
if (INCR_NUMBER_OF_POINTS_IN_CURRENT_ORGANE==  NUMBER_OF_POINTS_IN_CURRENT_ORGANE) break;
}
}
G4cout <<"G4DigiMouse-> number of points " <<NUMBER_OF_POINTS_IN_CURRENT_ORGANE << G4endl;
fs.close();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
if (this->pDetectorConstruction->ConstructSourceVolumePoints_Flag==true) {
BuildOrgansPositionDataFiles();

this->runManager->TerminateEventLoop();
} 
else {
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
ReadBinaryFile();
int NumberOfSameParticle=this->pDetectorConstruction->NumberOfSameParticle;
for (int i=0; i<NumberOfSameParticle ;i++) fParticleGun->GeneratePrimaryVertex(anEvent);

}
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

