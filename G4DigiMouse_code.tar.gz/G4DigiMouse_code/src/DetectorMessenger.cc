/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
G4Linac_MT, a simple-to-use open source code developed to facilitate the use of Geant4 C++ toolkit for
the simulation of medical linear accelerator.
Author: Pr. Jaafar EL Bakkali, Assistant Professor of Nuclear Physics, Rabat, Morocco.
E-mail: bahmedj@gmail.com
For documentation see http://G4Linac_MT.github.com
09/11/2018: public version 1.6
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
#include "DetectorMessenger.hh"
#include "DetectorConstruction.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithABool.hh"
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorMessenger::DetectorMessenger(DetectorConstruction* pDetectorConstruction)
: G4UImessenger(),fDetectorConstruction(pDetectorConstruction)
{
 DetectorDir           = new G4UIdirectory("/InterDosi/");
 DetectorDir           -> SetGuidance("............................");


 PrimaryParticleKineticEnergyCmd = new G4UIcmdWithADoubleAndUnit("/InterDosi/PrimaryParticleKineticEnergy",this);  
 PrimaryParticleKineticEnergyCmd->SetGuidance("PrimaryParticleKineticEnergy.");
 PrimaryParticleKineticEnergyCmd->SetParameterName("PrimaryParticleKineticEnergy",false);
 PrimaryParticleKineticEnergyCmd->SetUnitCategory("Energy");
 PrimaryParticleKineticEnergyCmd->SetRange("PrimaryParticleKineticEnergy>0.0");


MaxNumberOfPointsInOrganCmd = new G4UIcmdWithAnInteger("/InterDosi/MaxNumberOfPointsInOrgan",this);  
MaxNumberOfPointsInOrganCmd->SetGuidance("Set MaxNumberOfPointsInOrgan.");
MaxNumberOfPointsInOrganCmd ->SetParameterName("MaxNumberOfPointsInOrgan",false);
MaxNumberOfPointsInOrganCmd ->SetRange("MaxNumberOfPointsInOrgan>=0");


 PrimaryParticleNameCmd = new G4UIcmdWithAString("/InterDosi/PrimaryParticleName",this);  
 PrimaryParticleNameCmd->SetGuidance("PrimaryParticleName");
 PrimaryParticleNameCmd->SetParameterName("PrimaryParticleName",false);



 NumberOfSameParticle_Cmd = new G4UIcmdWithAnInteger("/InterDosi/NumberOfSameParticle",this);  
 NumberOfSameParticle_Cmd->SetGuidance("Set NumberOfSameParticle.");
 NumberOfSameParticle_Cmd ->SetParameterName("NumberOfSameParticle",false);
 NumberOfSameParticle_Cmd ->SetRange("NumberOfSameParticle>=0");
 NumberOfSameParticle_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 NumberOfThreads_Cmd = new G4UIcmdWithAnInteger("/InterDosi/NumberOfThreads",this);  
 NumberOfThreads_Cmd->SetGuidance("Set  Number Of Threads.");
 NumberOfThreads_Cmd ->SetParameterName("NumberOfThreads",false);
 NumberOfThreads_Cmd ->SetRange("NumberOfThreads>=0");
 NumberOfThreads_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);

ConstructSourceVolumePointsCmd = new G4UIcmdWithABool("/InterDosi/ConstructSourceVolumePoints",this);  
ConstructSourceVolumePointsCmd->SetGuidance("ConstructSourceVolumePoints.");
ConstructSourceVolumePointsCmd->SetParameterName("ConstructSourceVolumePoints",false);
ConstructSourceVolumePointsCmd->AvailableForStates(G4State_PreInit,G4State_Idle);


SourceOrganeNameCmd  = new G4UIcmdWithAString("/InterDosi/SourceOrganeName",this);
SourceOrganeNameCmd  ->SetGuidance("");
SourceOrganeNameCmd  ->SetParameterName("SourceOrganeName",false);
SourceOrganeNameCmd  ->SetDefaultValue("");
SourceOrganeNameCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorMessenger::~DetectorMessenger()
{
 
  delete PrimaryParticleNameCmd;
  delete PrimaryParticleKineticEnergyCmd;
  delete ConstructSourceVolumePointsCmd;
  delete DetectorDir;    
  delete PrimaryParticleKineticEnergyCmd;
  delete NumberOfSameParticle_Cmd;
  delete SourceOrganeNameCmd;
 delete MaxNumberOfPointsInOrganCmd;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{       
  if(command==NumberOfSameParticle_Cmd ){fDetectorConstruction->SetNumberOfSameParticle(NumberOfSameParticle_Cmd->GetNewIntValue(newValue));}  

else  if( command == MaxNumberOfPointsInOrganCmd){fDetectorConstruction-> SetMaxNumberOfPointsInOrgan(MaxNumberOfPointsInOrganCmd->GetNewIntValue(newValue));}  
else  if( command == NumberOfThreads_Cmd ){fDetectorConstruction-> SetNumberOfThreads(NumberOfThreads_Cmd->GetNewIntValue(newValue));}  
else if( command == PrimaryParticleKineticEnergyCmd ){ fDetectorConstruction->set_kinetic_energy(PrimaryParticleKineticEnergyCmd->GetNewDoubleValue(newValue));}
else if( command == PrimaryParticleNameCmd ){ fDetectorConstruction->set_particle_name(newValue);}
else if( command == ConstructSourceVolumePointsCmd ){ fDetectorConstruction->setConstructSourceVolumePoints_Flag(ConstructSourceVolumePointsCmd->GetNewBoolValue(newValue));}
else  if(command==SourceOrganeNameCmd ){fDetectorConstruction->SetSourceOrganeName(newValue);}   
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
