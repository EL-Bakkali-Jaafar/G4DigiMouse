//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// $Id: RunAction.cc 76943 2013-11-19 09:57:34Z gcosmo $
//

#include "RunAction.hh"
#include <ctime>
#include "G4Threading.hh"
#include <fstream>
#include <iostream>
#include "G4ios.hh"
#include <stdio.h>
#include <math.h>
#include "G4RunManager.hh"
#include <ctime>
#include  "DetectorConstruction.hh"
#include "G4Timer.hh"
using namespace std;
#include  "DetectorConstruction.hh"
#include "G4Timer.hh"
#include "G4Threading.hh"
G4Timer                     * myTimer;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
RunAction::RunAction()
{

myTimer                                     = new G4Timer();
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
RunAction::~RunAction()
{
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void RunAction::BeginOfRunAction(const G4Run* )
{
 if( IsMaster() )
{ 
myTimer->Start();
};
}



/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void RunAction::EndOfRunAction(const G4Run*)
{

myTimer->Stop();
this->cpu_time=myTimer->GetRealElapsed();

G4cout <<"CPU  TIME (S) " <<this->cpu_time <<G4endl;
this->runManager                    = G4RunManager::GetRunManager();
this->pDetectorConstruction = (DetectorConstruction*)(runManager->GetUserDetectorConstruction()); 
if (this->pDetectorConstruction->ConstructSourceVolumePoints_Flag==false) {
 std::ofstream  File;
File.open("sim.data", std::ios::out);
this->NumberOfThread =this->pDetectorConstruction ->NumberOfThread;
G4cout <<"END !  "  <<G4endl;
File <<this->pDetectorConstruction->SourceOrganeName+"_E"+ std::to_string(this->pDetectorConstruction->kinetic_energy) << "\n"<< this->cpu_time << "\n" <<this->NumberOfThread << "\n" <<this->runManager ->GetNumberOfEventsToBeProcessed()<< "\n" << this->pDetectorConstruction->NumberOfSameParticle << "\n"  <<this->pDetectorConstruction->kinetic_energy ;
File.close();
}
}


