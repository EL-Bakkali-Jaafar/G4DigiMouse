#ifndef InterDosi
#define InterDosi
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
typedef struct
{
string ORGANE_NAME;
double 
ORGANE_MASSE,
ORGANE_VOLUME,
KINETIC_ENERGY,
ABSORBED_ENERGY,
ABSORBED_ENERGY2,
STD_DEV;
unsigned  int NEVENT,PHOT_COUNT,CMPT_COUNT,PAIREE_COUNT;
int ORGANE_ID;
}InterDosiData;

#endif
