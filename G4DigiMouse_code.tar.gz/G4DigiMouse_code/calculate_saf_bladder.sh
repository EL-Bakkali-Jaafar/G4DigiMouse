

./G4DigiMouse  calculate_saf_bladder_0.1.mac  
g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

./Merge_Data




./G4DigiMouse  calculate_saf_bladder_0.5.mac  
g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

./Merge_Data



./G4DigiMouse  calculate_saf_bladder_0.050.mac  
g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

./Merge_Data



./G4DigiMouse  calculate_saf_bladder_1.mac  
g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

./Merge_Data



./G4DigiMouse  calculate_saf_bladder_4.mac  
g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

./Merge_Data


./G4DigiMouse  calculate_saf_bladder_0.015.mac  
g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

./Merge_Data

