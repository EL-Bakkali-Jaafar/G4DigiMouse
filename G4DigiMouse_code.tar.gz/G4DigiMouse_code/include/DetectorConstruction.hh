//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// $Id: DetectorConstruction.hh 69565 2013-05-08 12:35:31Z gcosmo $
//
/// \file DetectorConstruction.hh
/// \brief Definition of the DetectorConstruction class

#ifndef DetectorConstruction_h
#define DetectorConstruction_h 1

#include "G4VUserDetectorConstruction.hh"
#include "globals.hh"
#include "G4ThreeVector.hh"
#include <vector> 
class G4VPhysicalVolume;
class DetectorMessenger;
class G4LogicalVolume;
class G4Material;
class PhantomSD;
class G4tgrMessenger;
class G4RunManager;


using namespace std;
/// Detector construction class to define materials and geometry.

class DetectorConstruction : public G4VUserDetectorConstruction
{
public:
G4LogicalVolume* tmp[142];
G4VPhysicalVolume*  ptmp[4900480];
DetectorConstruction();
virtual ~DetectorConstruction();
virtual void ConstructSDandField();
G4Material *MaterialName(const G4int materialId);
int GetMaterialIdOfOrganId(const std::string OrganId_str);
void set_kinetic_energy(G4double _kinetic_energy);
G4ThreeVector GetLowerDimCubicVolumeEncapsulatingOrgan(G4float x, G4float y, G4float z ) ;
G4ThreeVector GetHigherDimCubicVolumeEncapsulatingOrgan(G4float x, G4float y, G4float z ) ;
G4ThreeVector DimCubicVolumeEncapsulatingOrgan;
void Construct_ICRP_adult_male_ConstructSourceVolumePoints( G4ThreeVector* center_position) ;
G4ThreeVector DimCubicVolumeEncapsulatingOrganPos;
void setConstructSourceVolumePoints_Flag(bool  _particle_name) ;
bool ConstructSourceVolumePoints_Flag;
G4double GetOrganTotalVoxelizedVolume(const std::string _OrganTotalVoxelizedVolumeName);
virtual G4VPhysicalVolume* Construct();
G4VPhysicalVolume* physWorld ;
std::string  OrganeName(const G4int OrganeId);
void Construct_ICRP_adult_male( G4ThreeVector* ) ;
void ConstructLogicalVolumes(G4String _SourceOrganeName);
void ContructMaterial();
void SetMaxNumberOfPointsInOrgan(int );
G4double GetOrganeDensity(int  _organ_id);
void  SetSourceOrganeName( G4String _SourceOrganeName);
G4Material*  _material1; G4Material* _material2; G4Material*_material3;G4Material*_material4;G4Material*_material5; G4Material*_material6; G4Material* _material7; G4Material*_material8; G4Material*_material9; G4Material*_material10;
G4Material* _material11; G4Material* _material12; G4Material*_material13;G4Material*_material14;G4Material*_material15; G4Material*_material16; G4Material*_material17; G4Material*_material18; G4Material*_material19; G4Material*_material20;
G4Material* _material21; G4Material* _material22; G4Material*_material23;G4Material*_material24;G4Material*_material25; G4Material*_material26; G4Material*_material27; G4Material*_material28; G4Material*_material29; G4Material*_material30;
G4Material* _material31; G4Material* _material32; G4Material*_material33;G4Material*_material34;G4Material*_material35; G4Material*_material36; G4Material*_material37; G4Material*_material38; G4Material*_material39; G4Material*_material40;
G4Material* _material41; G4Material* _material42; G4Material*_material43;G4Material*_material44;G4Material*_material45; G4Material*_material46; G4Material*_material47; G4Material*_material48; G4Material*_material49; G4Material*_material50;G4Material*_material51;G4Material*_material52;G4Material*_material53;




G4Material*          Air_material;
G4Material*          Skin_material; 
G4Material*          Adipose_tissue_material;
G4Material*          Pancreas_material;    
G4Material*          Spleen_material  ;    
G4Material*          Stomach_material  ;    
G4Material*          Whole_brain_material;      
G4Material*          Bladder_material ;    
G4Material*          Testes_material  ;  
G4Material*          Soft_tissue_material ;      
G4Material*          Masseter_muscles_material;     
G4Material*          Eye_material;       
G4Material*          Heart_material;      
G4Material*          Skeleton_material  ;      
G4Material*          Liver_material  ;      
G4Material*          Kidney_material ;      
G4Material*          Adrenals_material  ;   
G4Material*          Lungs_material  ;         
G4Material*          soft;

int MaxNumberOfPointsInOrgan;
int Total_Events_To_Be_Processed;


    void SetNumberOfThreads(int);
   
    
    void SetNumberOfSameParticle(int);
    void set_particle_name( std::string  _particle_name) ;
    G4ThreeVector  GetReadOutGeometryCenterPosition() ;

    int NUMBER_OF_THREADS,NumberOfSameParticle,NumberOfThread;
    G4double kinetic_energy;
    G4String sensitiveDetectorName; 

    //
    PhantomSD* mPhantomSD;//pointer to sensitive detector

    static G4ThreadLocal G4bool fConstructedSDandField;
    DetectorMessenger * pDetectorMessenger;
   G4tgrMessenger * messenger; 
   std::string particle_name;
 G4String SourceOrganeName;
G4RunManager* runManager;
};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif

