
#ifndef Voxel
#define voxel

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

struct vx
{
string organe;
	
};
#endif









