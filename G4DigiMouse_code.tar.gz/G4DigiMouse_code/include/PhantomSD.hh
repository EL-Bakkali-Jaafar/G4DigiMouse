/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
G4Linac_MT, a simple-to-use open source code developed to facilitate the use of Geant4 C++ toolkit for
the simulation of medical linear accelerator.
Author: Pr. Jaafar EL Bakkali, Assistant Professor of Nuclear Physics, Rabat, Morocco.
E-mail: bahmedj@gmail.com
For documentation see http://G4Linac_MT.github.com
09/11/2018: public version 1.6
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
#ifndef PhantomSD_h
#define PhantomSD_h 1
#include "G4ThreeVector.hh"
#include "G4VSensitiveDetector.hh"
#include "G4VTouchable.hh"
#include <vector>
#include "G4ios.hh"
#include <stdio.h>
#include "G4Threading.hh"
using namespace std;
class G4Step;
class G4HCofThisEvent;
class G4TouchableHistory;
class DetectorConstruction;
class G4RunManager;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
class  PhantomSD : public G4VSensitiveDetector
{
public:
PhantomSD(
G4String name);
~PhantomSD();

G4bool ProcessHits(G4Step*aStep,G4TouchableHistory*);
void EndOfEvent(G4HCofThisEvent*HCE);
void clear();
void DrawAll();
void PrintAll();
void SaveDataInBinaryFile(); 
void SaveDataInTextFile(); 
typedef struct
{
string ORGANE_NAME;
G4double 
ORGANE_MASSE,
ORGANE_VOLUME,
KINETIC_ENERGY,
ABSORBED_ENERGY,
ABSORBED_ENERGY2,
STD_DEV;
unsigned  int NEVENT,PHOT_COUNT,CMPT_COUNT,PAIREE_COUNT;
G4int ORGANE_ID;
}InterDosiData;

private:
G4double x;
G4double y;
G4double z;
int Total_Events,Total_Events_To_Be_Processed,NumberOfThreads;


G4String NameOfPhantomPhysicalVolume;
G4String DOSIMETRIC_DATA_FileName;

G4ThreeVector HalfSize;
G4ThreeVector pos;
G4double HalfVoxelDimensionAlongX, HalfVoxelDimensionAlongY, HalfVoxelDimensionAlongZ;
G4int NumberTotalEvents, NumberOfVoxelsAlongX, NumberOfVoxelsAlongY, NumberOfVoxelsAlongZ;
G4double VoxelMass, density, VoxelVolume;
DetectorConstruction* pDetectorConstruction;  
G4ThreadLocal  static int INCREMENTOR;
G4double BODY_MASSE=0;
G4double ORGANE_MASSE=0;
G4double TOTAL_EMITTED_ENERGY_FROM_SOURCE_ORGANE=0;
InterDosiData *_InterDosiData;
G4float SAF,PHOT_COUNT,CMPT_COUNT,TOTAL_EMITTED_ENERGY_FROM_SOURCE_AND_RECEIVED_BY_TARGET,ABSORBED_ENERGY,OrganTotalVoxelizedVolume;
G4int NEVENT;
G4RunManager* runManager;
};
#endif
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
