/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
G4Linac_MT, a simple-to-use open source code developed to facilitate the use of Geant4 C++ toolkit for
the simulation of medical linear accelerator.
Author: Pr. Jaafar EL Bakkali, Assistant Professor of Nuclear Physics, Rabat, Morocco.
E-mail: bahmedj@gmail.com
For documentation see http://G4Linac_MT.github.com
09/11/2018: public version 1.6
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
#ifndef DetecorMessenger_h
#define DetecorMessenger_h 1

#include "globals.hh"
#include "G4UImessenger.hh"

class  DetectorConstruction;
class  G4UIdirectory;
class  G4UIcmdWithADoubleAndUnit;
class  G4UIcmdWithAString;
class  G4UIcmdWithAnInteger;
class  G4UIcmdWith3VectorAndUnit;
class  G4UIcmdWithAString;
class  G4UIcmdWithABool;
class  DetectorMessenger: public G4UImessenger
{
  public:
    DetectorMessenger(DetectorConstruction* );
   ~DetectorMessenger();
    void SetNewValue(G4UIcommand*, G4String); 
  private:
DetectorConstruction         * fDetectorConstruction;
G4UIcmdWithAString           * PrimaryParticleNameCmd;
G4UIdirectory                * DetectorDir;   
G4UIcmdWithAnInteger         * NumberOfSameParticle_Cmd;
G4UIcmdWithAnInteger         * NumberOfThreads_Cmd;
G4UIcmdWithAnInteger         * MaxNumberOfPointsInOrganCmd;
G4UIcmdWithADoubleAndUnit    * PrimaryParticleKineticEnergyCmd;
G4UIcmdWithABool             * ConstructSourceVolumePointsCmd  ;
G4UIcmdWithAString           * SourceOrganeNameCmd;



};
#endif
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
