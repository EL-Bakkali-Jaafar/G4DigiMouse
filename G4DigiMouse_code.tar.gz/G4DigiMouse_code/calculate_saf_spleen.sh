
#./G4DigiMouse  calculate_saf_spleen_0.1.mac  
#g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

#./Merge_Data




#./G4DigiMouse  calculate_saf_spleen_0.5.mac  
#g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

#./Merge_Data



#./G4DigiMouse  calculate_saf_spleen_0.015.mac  
#g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

#./Merge_Data



#./G4DigiMouse  calculate_saf_spleen_0.050.mac  
#g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

#./Merge_Data



#./G4DigiMouse  calculate_saf_spleen_1.mac  
#g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

#./Merge_Data



./G4DigiMouse  calculate_saf_spleen_4.mac  
g++ -std=c++11 -g -Wall  Merge_Data.cc   -o Merge_Data

./Merge_Data



